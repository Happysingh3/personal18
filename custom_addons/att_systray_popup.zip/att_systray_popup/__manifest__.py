{
    "name": "Attendance Systray Popup",
    "version": "1.0",
    "summary": "Red dot click -> popup with Check in / Break in / Break out / Check out",
    "depends": ["web", "hr_attendance"],
    "data": [
        "security/ir.model.access.csv"
    ],
    "assets": {
        "web.assets_backend": [
            "att_systray_popup/static/src/js/systray_popup.js"
        ]
    },
    "license": "LGPL-3"
}