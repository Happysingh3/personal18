/** @odoo-module **/

// ---------- JSON-RPC ----------
const KW = (model, method) => `/web/dataset/call_kw/${model}/${method}`;
async function rpcCall(model, method, args = [], kwargs = {}) {
    const res = await fetch(KW(model, method), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method: "call", params: { model, method, args, kwargs } }),
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.data?.message || data.error.message || "RPC error");
    return data.result;
}

// ---------- Time helpers ----------
function localDayRangeUTC() {
    const d = new Date();
    const startLocal = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const endLocal = new Date(startLocal.getTime() + 24 * 3600 * 1000);
    const fmt = (x) => x.toISOString().slice(0,19).replace("T"," ");
    return [fmt(startLocal), fmt(endLocal)];
}
function utcToLocalTimeStr(utcStr) {
    if (!utcStr) return null;
    const dt = new Date(utcStr.replace(" ","T")+"Z");
    return dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
function nowUTC(){ return new Date().toISOString().slice(0,19).replace("T"," "); }
function nowTimeStr(){ return new Date().toLocaleTimeString([], { hour:"2-digit", minute:"2-digit", second:"2-digit"}); }

// ---------- UI helpers ----------
function setDisabled(el, yes){ el.disabled = !!yes; el.classList.toggle("o_disabled", !!yes); }
function setDefaultLabels(bIn,bBrIn,bBrOut,bOut){
  bIn.textContent="Check in"; bBrIn.textContent="Break in"; bBrOut.textContent="Break out"; bOut.textContent="Check out";
}

// ---------- Employee + Today status ----------
let __EMP_ID = null;
async function getEmpId(){
  if (__EMP_ID) return __EMP_ID;
  const uid = window.odoo?.session_info?.uid || window.odoo?.__session_info__?.uid || null;
  const rec = await rpcCall("hr.employee","search_read", [[["user_id","=",uid]],["id"]], {limit:1});
  if (!rec.length) throw new Error("No employee linked to current user.");
  __EMP_ID = rec[0].id; return __EMP_ID;
}

// OLD getTodayStatus(...) को हटा दें और नीचे वाला रखें
async function getTodayStatus(empId) {
  const [startUTC, endUTC] = localDayRangeUTC();

  // 1) आज का attendance (check_in / check_out)
  const atts = await rpcCall(
    "hr.attendance", "search_read",
    [[["employee_id","=",empId], ["check_in",">=",startUTC], ["check_in","<",endUTC]],
     ["id","check_in","check_out"]],
    { order: "check_in asc", limit: 1 }
  );
  const att = atts[0] || null;

  // 2) आज के breaks (start/end/is_active)  → यहीं से break in/out time मिल जाएगा
  let brIn = null, brOut = null, active = false, any = false;
  const brs = await rpcCall(
    "hr.attendance.break", "search_read",
    [[["employee_id","=",empId], ["start",">=",startUTC], ["start","<",endUTC]],
     ["start","end","is_active"]],
    { order: "start asc" }
  );
  if (brs.length) {
    any = true;
    brIn = brs[0].start || null;                          // दिन का पहला break-in
    const last = brs[brs.length - 1];
    active = !!last.is_active;
    brOut = active ? null : (last.end || null);           // अगर active नहीं है तो आख़िरी end
  }

  return {
    attId: att?.id || null,
    inUTC: att?.check_in || null,
    outUTC: att?.check_out || null,
    brInUTC: brIn,
    brOutUTC: brOut,
    breakUsed: any,
    breakActive: active,
  };
}

// ---------- State machine ----------
/*
  - "not_in"             : only Check in
  - "in"                 : Break in + Check out
  - "break" (active)     : Break out + Check out
  - "in_after_break"     : only Check out (break already done)
  - "done_out"           : all disabled
*/
function deriveState(st){
  if (!st.attId) return "not_in";
  if (st.outUTC) return "done_out";
  if (st.brInUTC && !st.brOutUTC) return "break";
  if (st.brInUTC && st.brOutUTC) return "in_after_break";
  return "in";
}
function applyState(state,bIn,bBrIn,bBrOut,bOut){
  setDefaultLabels(bIn,bBrIn,bBrOut,bOut);
  if (state==="not_in"){ setDisabled(bIn,false); setDisabled(bBrIn,true); setDisabled(bBrOut,true); setDisabled(bOut,true); }
  else if (state==="in"){ setDisabled(bIn,true); setDisabled(bBrIn,false); setDisabled(bBrOut,true); setDisabled(bOut,false); }
  else if (state==="break"){ setDisabled(bIn,true); setDisabled(bBrIn,true); setDisabled(bBrOut,false); setDisabled(bOut,false); }
  else if (state==="in_after_break"){ setDisabled(bIn,true); setDisabled(bBrIn,true); setDisabled(bBrOut,true); setDisabled(bOut,false); }
  else { setDisabled(bIn,true); setDisabled(bBrIn,true); setDisabled(bBrOut,true); setDisabled(bOut,true); }
}
function fillLabels(st,bIn,bBrIn,bBrOut,bOut){
  if (st.inUTC)  bIn.textContent   = `Check in ${utcToLocalTimeStr(st.inUTC)}`;
  if (st.brInUTC)  bBrIn.textContent = `Break in ${utcToLocalTimeStr(st.brInUTC)}`;
  if (st.brOutUTC) bBrOut.textContent= `Break out ${utcToLocalTimeStr(st.brOutUTC)}`;
  if (st.outUTC)   bOut.textContent  = `Check out ${utcToLocalTimeStr(st.outUTC)}`;
}

// ---------- Popup ----------
function popupHTML(){
  return `
  <div class="aebo-att-overlay" style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.35);z-index:1050;">
    <div class="aebo-att-dialog o_dialog" style="min-width:420px;background:#fff;border-radius:12px;padding:18px;box-shadow:0 10px 30px rgba(0,0,0,.2);">
      <h3 style="margin:0 0 12px 0;font-weight:600;">Attendance</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <button type="button" class="btn btn-success aebo-checkin">Check in</button>
        <button type="button" class="btn btn-secondary aebo-breakin">Break in</button>
        <button type="button" class="btn btn-warning aebo-breakout">Break out</button>
        <button type="button" class="btn btn-danger aebo-checkout">Check out</button>
      </div>
      <p class="aebo-status" style="margin:10px 0 0;color:#b00020;font-size:13px;"></p>
      <div style="margin-top:10px;text-align:right;">
        <button type="button" class="btn btn-link aebo-close">Close</button>
      </div>
    </div>
  </div>`;
}

async function openPopup(){
  const wrap = document.createElement("div"); wrap.innerHTML = popupHTML();
  const overlay = wrap.firstElementChild; document.body.appendChild(overlay);
  const $ = (sel)=>overlay.querySelector(sel);

  const s = $(".aebo-status");
  const bIn=$(".aebo-checkin"), bBrIn=$(".aebo-breakin"), bBrOut=$(".aebo-breakout"), bOut=$(".aebo-checkout");
  const close=()=>overlay?.remove();
  overlay.addEventListener("click",(e)=>{ if(e.target.classList.contains("aebo-att-overlay")) close(); });
  $(".aebo-close").addEventListener("click", close);

  let empId=null, st=null, state="not_in";

  try{
    empId = await getEmpId();
    st = await getTodayStatus(empId);
    state = deriveState(st);
    applyState(state,bIn,bBrIn,bBrOut,bOut);
    fillLabels(st,bIn,bBrIn,bBrOut,bOut);
  }catch(e){ s.textContent = e.message || String(e); }

  // Actions (once per day)
  bIn.addEventListener("click", async ()=>{
    try{
      st = await getTodayStatus(empId);
      if (st.attId){ state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut); fillLabels(st,bIn,bBrIn,bBrOut,bOut); return; }
      const attId = await rpcCall("hr.attendance","create", [[{employee_id: empId, check_in: nowUTC(), in_mode: "systray"}]]);
      bIn.textContent = `Check in ${nowTimeStr()}`;
      st = await getTodayStatus(empId);
      state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut);
      document.querySelector(".o_menu_systray button")?.dispatchEvent(new Event("mouseover"));
    }catch(e){ s.textContent = e.message || String(e); }
  });

  bBrIn.addEventListener("click", async ()=>{
    try{
      st = await getTodayStatus(empId);
      // केवल एक break per day
      if (!st.attId || st.brInUTC){ state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut); fillLabels(st,bIn,bBrIn,bBrOut,bOut); return; }
      await rpcCall("hr.attendance","aebo_break_in", []);
      bBrIn.textContent = `Break in ${nowTimeStr()}`;
      st = await getTodayStatus(empId);
      state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut);
    }catch(e){ s.textContent = e.message || String(e); }
  });

  bBrOut.addEventListener("click", async ()=>{
    try{
      st = await getTodayStatus(empId);
      if (!st.attId || !st.brInUTC || st.brOutUTC){ state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut); fillLabels(st,bIn,bBrIn,bBrOut,bOut); return; }
      await rpcCall("hr.attendance","aebo_break_out", []);
      bBrOut.textContent = `Break out ${nowTimeStr()}`;
      st = await getTodayStatus(empId);
      state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut);
    }catch(e){ s.textContent = e.message || String(e); }
  });

  bOut.addEventListener("click", async ()=>{
    try{
      st = await getTodayStatus(empId);
      if (!st.attId || st.outUTC){ state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut); fillLabels(st,bIn,bBrIn,bBrOut,bOut); return; }
      // FIX: write signature → ([ids], vals)
      await rpcCall("hr.attendance","write", [[st.attId], { check_out: nowUTC(), out_mode: "systray" }]);
      bOut.textContent = `Check out ${nowTimeStr()}`;
      st = await getTodayStatus(empId);
      state = deriveState(st); applyState(state,bIn,bBrIn,bBrOut,bOut);
      document.querySelector(".o_menu_systray button")?.dispatchEvent(new Event("mouseover"));
    }catch(e){ s.textContent = e.message || String(e); }
  });
}

// ---------- Hook systray ----------
const SEL = [
  ".o_menu_systray .o_attendance_status",
  ".o_menu_systray .o_attendance_systray",
  ".o_menu_systray i.fa-circle.text-danger",
  ".o_menu_systray i.fa-circle.text-success",
];
function hookSystray(){
  let ok=false;
  for (const s of SEL){
    document.querySelectorAll(s).forEach((el)=>{
      const host=el.closest("button,a,span,div"); if(!host || host.dataset.attSystrayHooked) return;
      host.dataset.attSystrayHooked="1";
      host.addEventListener("click",(ev)=>{ ev.preventDefault(); ev.stopPropagation(); openPopup(); }, true);
      ok=true;
    });
  }
  return ok;
}
(function boot(){
  const start=Date.now(), MAX=8000;
  function tryHook(){ if(hookSystray()) return;
    if(Date.now()-start<MAX) setTimeout(tryHook,300);
    else new MutationObserver(()=>hookSystray()).observe(document.body,{childList:true,subtree:true}); }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", tryHook); else tryHook();
})();