from odoo import api, fields, models, _
from odoo.exceptions import UserError
import pytz
from dateutil.relativedelta import relativedelta

class HrAttendance(models.Model):
    _inherit = "hr.attendance"
    break_in  = fields.Datetime(string="Break In")
    break_out = fields.Datetime(string="Break Out")

    @api.model
    def aebo_break_in(self):
        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))
        att = self.search([('employee_id','=', emp.id), ('check_out','=', False)], limit=1)
        if not att:
            raise UserError(_("You must check in first."))
        if att.break_in:
            raise UserError(_("A break is already active or already used today."))
        att.write({'break_in': fields.Datetime.now()})
        return {'ok': True, 'break_in': att.break_in}

    @api.model
    def aebo_break_out(self):
        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))
        att = self.search([('employee_id','=', emp.id), ('check_out','=', False)], limit=1)
        if not att or not att.break_in:
            raise UserError(_("No active break."))
        if att.break_out:
            raise UserError(_("Break already completed."))
        att.write({'break_out': fields.Datetime.now()})
        return {'ok': True, 'break_out': att.break_out}