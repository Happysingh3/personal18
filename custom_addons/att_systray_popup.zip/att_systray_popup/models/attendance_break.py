from odoo import api, fields, models, _
from odoo.exceptions import UserError

class HrAttendanceBreak(models.Model):
    _name = "hr.attendance.break"
    _description = "Attendance Break"
    _order = "start desc"

    employee_id = fields.Many2one("hr.employee", required=True, ondelete="cascade", index=True)
    start = fields.Datetime(string="Break In", required=True)
    end = fields.Datetime(string="Break Out")
    is_active = fields.Boolean(string="Active", compute="_compute_is_active", store=False)
    duration_hours = fields.Float(compute="_compute_duration", string="Duration (hrs)", store=True)

    @api.depends("start", "end")
    def _compute_is_active(self):
        for rec in self:
            rec.is_active = bool(rec.start and not rec.end)

    @api.depends("start", "end")
    def _compute_duration(self):
        for rec in self:
            if rec.start and rec.end:
                delta = fields.Datetime.to_datetime(rec.end) - fields.Datetime.to_datetime(rec.start)
                rec.duration_hours = delta.total_seconds() / 3600.0
            else:
                rec.duration_hours = 0.0

    def _employee_from_user(self):
        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))
        return emp

    @api.model
    def action_break_in(self):
        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))

        # must be checked in
        open_att = self.env["hr.attendance"].search([("employee_id", "=", emp.id), ("check_out", "=", False)], limit=1)
        if not open_att:
            raise UserError(_("You must check in first."))

        # only one active break at a time
        active = self.search([("employee_id", "=", emp.id), ("end", "=", False)], limit=1)
        if active:
            raise UserError(_("A break is already active."))

        br = self.create({"employee_id": emp.id, "start": fields.Datetime.now()})
        return {"ok": True, "start": br.start}

    @api.model
    def action_break_out(self):
        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))

        active = self.search([("employee_id", "=", emp.id), ("end", "=", False)], order="start desc", limit=1)
        if not active:
            raise UserError(_("No active break."))

        active.write({"end": fields.Datetime.now()})
        return {"ok": True, "end": active.end}

    @api.model
    def aebo_get_status(self):
        """Return current user's attendance/break state."""
        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))
        open_att = self.search([
            ("employee_id", "=", emp.id),
            ("check_out", "=", False),
        ], order="check_in desc", limit=1)
        active_break = self.env["hr.attendance.break"].search([
            ("employee_id", "=", emp.id),
            ("is_active", "=", True),
        ], limit=1)
        return {
            "checked_in": bool(open_att),
            "break_active": bool(active_break),
        }

    @api.model
    def aebo_attendance_action(self, action):
        """
        Explicit check-in / check-out from systray popup.
        action in {"check_in", "check_out"}.
        """
        if action not in ("check_in", "check_out"):
            raise UserError(_("Invalid action."))

        emp = self.env.user.employee_id
        if not emp:
            raise UserError(_("No employee linked to current user."))

        now = fields.Datetime.now()
        open_att = self.search([
            ("employee_id", "=", emp.id),
            ("check_out", "=", False),
        ], order="check_in desc", limit=1)

        if action == "check_in":
            if open_att:
                raise UserError(_("Already checked in."))
            self.create({
                "employee_id": emp.id,
                "check_in": now,
                "in_mode": "systray",
            })
            return {"state": "in", "when": now}

        # action == "check_out"
        if not open_att:
            raise UserError(_("No open attendance to check out."))
        open_att.write({
            "check_out": now,
            "out_mode": "systray",
        })
        return {"state": "out", "when": now}